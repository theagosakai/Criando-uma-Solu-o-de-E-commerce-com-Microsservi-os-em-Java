# LABs

# 056_CriandoSolucaoECommerceComMicrosservicosEmJava

Criando uma solução de e-commerce com microsserviços em Java

Neste projeto prático iremos desenvolver uma solução de e-commerce com a arquitetura de microsserviços e aplicar a integração entre eles orientada a eventos com Apache Kafka e garantir a compatibilidade entre da comunicação dos microsserviços com Schema Registry. Para isso, programaremos em Java utilizando a stack do Spring (Spring Boot, Spring Cloud Streams).

Java Back-End Intermediário

ESPECIALISTA

#### Daniel Hatanaka
Engenheiro de software, PagSeguro PagBank

https://web.digitalinnovation.one/project/criando-uma-solucao-de-e-commerce-com-microsservicos-em-java/learning/506c1caf-2543-42cf-91f7-f4e28f2657ab?back=/track/capgemini-fullstack-java-and-angular

